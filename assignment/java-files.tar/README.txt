There are two files you have to use in your project. 

1) build.xml -- ant build file
Use this file to build the project and this way we can automate the process of testing your middleware. The 'jar' target will produce a jar file that has your ETH short id in it. 

IMPORTANT: modify the xml file so that the .jar is built with your name (look for the definition at the beginning of the file)

2) RunMW class -- main class you have to use
This is to ensure that all your projects take the right amount of parameters and can be started exactly the same. To use this class please copy it into the ./src folder. 
IMPORTANT: you will have to fix the package name in the first line of this file, to match the one you have in your project. Then you will have to update this in the Ant file (build.xml) so that it finds the main class. 
